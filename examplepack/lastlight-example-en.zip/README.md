# LastLight Example Pack EN

This is demonstration data bundled only so the LastLight repository can be tried immediately.

It is not an official emergency knowledge release and should not replace current guidance from local authorities or primary sources.

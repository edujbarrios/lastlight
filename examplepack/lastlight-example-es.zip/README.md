# LastLight example pack

This archive exists only to demonstrate how LastLight loads and searches a downloaded knowledge pack.
It is intentionally small and combines several topics that would normally be distributed as separate packs.
For real-world emergency decisions, consult current local authorities and the original sources.
